export class Book {
    id:number
    title:string
    auther:string
    
}